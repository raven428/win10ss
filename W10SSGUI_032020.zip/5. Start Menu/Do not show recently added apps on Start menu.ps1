﻿# Do not show recently added apps on Start menu
#! Do not modify this string
# Не показывать недавно добавленные приложения в меню "Пуск"
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name HideRecentlyAddedApps -PropertyType DWord -Value 1 -Force