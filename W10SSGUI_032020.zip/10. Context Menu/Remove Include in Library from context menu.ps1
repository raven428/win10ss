﻿# Remove "Include in Library" from context menu
#! Do not modify this string
# Удалить пункт "Добавить в библиотеку" из контекстного меню
#! Не изменяйте эту строку
New-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Folder\shellex\ContextMenuHandlers\Library Location" -Name "(default)" -PropertyType String -Value "-{3dad6c5d-2167-4cae-9914-f99e41c12cfa}" -Force