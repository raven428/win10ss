﻿# Remove "Compressed (zipped) Folder" from context menu
#! Do not modify this string
# Удалить пункт "Сжатая ZIP-папка" из контекстного меню
#! Не изменяйте эту строку
Remove-Item -Path Registry::HKEY_CLASSES_ROOT\.zip\CompressedFolder\ShellNew -Force -ErrorAction Ignore