﻿# Remove "Edit with Photos" from context menu
#! Do not modify this string
# Удалить пункт "Изменить с помощью приложения "Фотографии"" из контекстного меню
#! Не изменяйте эту строку
New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellEdit -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force