﻿# Make the "Open", "Print", "Edit" context menu items available, when more than 15 selected
# По умолчанию эти пункты контекстного меню отображаются, если выбрано не более 15 пунктов
# Сделать доступными элементы контекстного меню "Открыть", "Изменить" и "Печать" при выделении более 15 элементов
# By default, these context menu items are displayed if not more than 15 items are selected
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name MultipleInvokePromptMinimum -PropertyType DWord -Value 300 -Force