﻿# Turn off "Connected User Experiences and Telemetry" service
#! Do not modify this string
# Отключить службу "Функциональные возможности для подключенных пользователей и телеметрия"
#! Не изменяйте эту строку
Get-Service -Name DiagTrack | Stop-Service -Force
Get-Service -Name DiagTrack | Set-Service -StartupType Disabled