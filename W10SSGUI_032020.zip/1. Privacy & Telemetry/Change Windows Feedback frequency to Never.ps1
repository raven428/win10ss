﻿# Change Windows Feedback frequency to "Never"
#! Do not modify this string
# Изменить частоту формирования отзывов на "Никогда"
#! Не изменяйте эту строку
IF (-not (Test-Path -Path HKCU:\Software\Microsoft\Siuf\Rules))
{
	New-Item -Path HKCU:\Software\Microsoft\Siuf\Rules -Force
}
New-ItemProperty -Path HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod -PropertyType DWord -Value 0 -Force