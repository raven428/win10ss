﻿# Turn off automatic installing suggested apps
# Windows silently automatically downloads and installs suggested apps from the Microsoft Store without any confirmation by default
# Отключить автоматическую установку рекомендованных приложений
# По умолчанию Windows в тихом режиме и без подтверждения автоматически скачивает и устаналвивает рекомендованные приложения из Microsoft Store
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SilentInstalledAppsEnabled -PropertyType DWord -Value 0 -Force