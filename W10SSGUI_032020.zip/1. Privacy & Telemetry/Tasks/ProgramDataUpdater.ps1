﻿# Collects program telemetry information if opted-in to the Microsoft Customer Experience Improvement Program
# Сбор телеметрических данных программы при участии в программе улучшения качества ПО
Get-ScheduledTask -TaskName "ProgramDataUpdater" | Disable-ScheduledTask