﻿# Initializes Family Safety monitoring and enforcement
# Инициализация контроля и применения правил семейной безопасности
Get-ScheduledTask -TaskName "FamilySafetyMonitor" | Disable-ScheduledTask