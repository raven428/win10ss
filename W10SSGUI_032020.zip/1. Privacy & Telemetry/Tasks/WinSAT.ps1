﻿# Measures a system's performance and capabilities
# Измеряет быстродействие и возможности системы
Get-ScheduledTask -TaskName "WinSAT" | Disable-ScheduledTask