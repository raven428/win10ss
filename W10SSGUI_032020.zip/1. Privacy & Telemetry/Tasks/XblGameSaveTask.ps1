﻿# XblGameSave Standby Task
# XblGameSave Standby Task
Get-ScheduledTask -TaskName "XblGameSaveTask" | Disable-ScheduledTask