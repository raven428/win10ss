﻿# Turn on tip, trick, and suggestions as you use Windows
#! Do not modify this string
# Показывать советы, подсказки и рекомендации при использованию Windows
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338389Enabled -PropertyType DWord -Value 1 -Force