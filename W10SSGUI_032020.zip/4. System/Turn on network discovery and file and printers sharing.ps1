﻿# Turn on network discovery and file and printers sharing
#! Do not modify this string
# Включить сетевое обнаружение и общий доступ к файлам и принтерам
#! Не изменяйте эту строку
if ((Get-NetConnectionProfile).NetworkCategory -ne "DomainAuthenticated")
{
	Get-NetFirewallRule -Group "@FirewallAPI.dll,-32752", "@FirewallAPI.dll,-28502" | Set-NetFirewallRule -Profile Private -Enabled True
	Set-NetConnectionProfile -NetworkCategory Private
}