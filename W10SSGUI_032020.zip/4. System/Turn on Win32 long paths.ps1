﻿# Turn on Win32 long paths
#! Do not modify this string
# Включить длинные пути Win32
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem -Name LongPathsEnabled -PropertyType DWord -Value 1 -Force