﻿# Turn on automatic backup the system registry to the %SystemRoot%\System32\config\RegBack folder
#! Do not modify this string
# Включить автоматическое создание копии реестра в папку %SystemRoot%\System32\config\RegBack
#! Не изменяйте эту строку
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager" -Name EnablePeriodicBackup -PropertyType DWord -Value 1 -Force