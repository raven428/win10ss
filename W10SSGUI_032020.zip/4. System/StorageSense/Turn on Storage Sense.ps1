﻿# Turn on Storage Sense
#! Do not modify this string
# Включить Память устройства
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 01 -PropertyType DWord -Value 1 -Force