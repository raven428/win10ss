﻿# Never delete files in "Downloads" folder
#! Do not modify this string
# Никогда не удалять файлы из папки "Загрузки"
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 512 -PropertyType DWord -Value 0 -Force