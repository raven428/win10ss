﻿# Turn on access to mapped drives from app running with elevated permissions with Admin Approval Mode enabled
#! Do not modify this string
# Включить доступ к сетевым дискам при включенном режиме одобрения администратором при доступе из программ, запущенных с повышенными правами
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLinkedConnections -PropertyType DWord -Value 1 -Force