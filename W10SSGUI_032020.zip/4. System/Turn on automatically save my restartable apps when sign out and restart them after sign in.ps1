﻿# Turn on automatically save my restartable apps when sign out and restart them after sign in
#! Do not modify this string
# Автоматически сохранять мои перезапускаемые приложения при выходе из системы и перезапустить их после выхода
#! Не изменяйте эту строку
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name RestartApps -Value 1 -Force