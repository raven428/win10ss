﻿# Turn off hibernate
#! Do not modify this string
# Отключить гибридный спящий режим
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Power -Name HibernateEnabled -PropertyType DWord -Value 0 -Force