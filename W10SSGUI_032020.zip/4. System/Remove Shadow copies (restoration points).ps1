﻿# Remove Shadow copies (restoration points)
#! Do not modify this string
# Удалить теневые копии (точки восстановения)
#! Не изменяйте эту строку
Get-CimInstance -ClassName Win32_ShadowCopy | Remove-CimInstance