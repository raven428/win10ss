﻿# Turn on Num Lock at startup
#! Do not modify this string
# Включить Num Lock при загрузке
#! Не изменяйте эту строку
New-ItemProperty -Path "Registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -PropertyType String -Value 2147483650 -Force