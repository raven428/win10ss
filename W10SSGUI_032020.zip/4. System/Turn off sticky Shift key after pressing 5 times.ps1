﻿# Turn off sticky Shift key after pressing 5 times
#! Do not modify this string
# Отключить залипание клавиши Shift после 5 нажатий
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" -Name Flags -PropertyType String -Value 506 -Force