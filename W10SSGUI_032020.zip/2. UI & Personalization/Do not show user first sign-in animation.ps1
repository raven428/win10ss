﻿# Do not show user first sign-in animation
#! Do not modify this string
# Не показывать анимацию при первом входе в систему
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation -PropertyType DWord -Value 0 -Force