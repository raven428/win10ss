﻿# Choose theme color for default Windows mode
# Выбрать режим Windows по умолчанию
Do
{
	$theme = Read-Host -Prompt " "
	IF ($theme -eq "L")
	{
		# Show color only on taskbar
		# Отображать цвет элементов только на панели задач
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence -PropertyType DWord -Value 0 -Force
		# Light Theme Color for Default Windows Mode
		# Режим Windows по умолчанию светлый
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 1 -Force
	}
	elseif ($theme -eq "D")
	{
		# Turn on the display of color on Start menu, taskbar, and action center
		# Отображать цвет элементов в меню "Пуск", на панели задач и в центре уведомлений
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence -PropertyType DWord -Value 1 -Force
		# Dark Theme Color for Default Windows Mode
		# Режим Windows по умолчанию темный
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 0 -Force
	}
}
Until ($theme -eq "L" -or $theme -eq "D")