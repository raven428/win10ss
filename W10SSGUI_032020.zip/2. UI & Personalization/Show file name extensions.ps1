﻿# Show file name extensions
#! Do not modify this string
# Показывать расширения для зарегистрированных типов файлов
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt -PropertyType DWord -Value 0 -Force