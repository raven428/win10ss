﻿# Hide search box or search icon on taskbar
#! Do not modify this string
# Скрыть поле или значок поиска на панели задач
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode -PropertyType DWord -Value 0 -Force