﻿# Do not show Task View button on taskbar
#! Do not modify this string
# Не показывать кнопку Просмотра задач
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton -PropertyType DWord -Value 0 -Force