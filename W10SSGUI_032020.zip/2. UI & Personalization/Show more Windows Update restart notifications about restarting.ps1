﻿# Show more Windows Update restart notifications about restarting
#! Do not modify this string
# Показывать уведомление, когда компьютеру требуется перезагрузка для завершения обновления
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2 -PropertyType DWord -Value 1 -Force