﻿# Show accent color on the title bars and window borders
#! Do not modify this string
# Отображать цвет элементов в заголовках окон и границ окон
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\DWM -Name ColorPrevalence -PropertyType DWord -Value 1 -Force