﻿# Show seconds on taskbar clock
#! Do not modify this string
# Отображать секунды в системных часах на панели задач
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSecondsInSystemClock -PropertyType DWord -Value 1 -Force