﻿# Do not show "Frequent folders" in Quick access
#! Do not modify this string
# Не показывать недавно используемые папки на панели быстрого доступа
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent -PropertyType DWord -Value 0 -Force