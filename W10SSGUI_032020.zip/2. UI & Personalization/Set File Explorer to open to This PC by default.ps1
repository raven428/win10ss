﻿# Set File Explorer to open to This PC by default
#! Do not modify this string
# Открывать "Этот компьютер" в Проводнике
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo -PropertyType DWord -Value 1 -Force