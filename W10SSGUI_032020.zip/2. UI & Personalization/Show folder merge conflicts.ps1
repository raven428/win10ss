﻿# Show folder merge conflicts
#! Do not modify this string
# Не скрывать конфликт слияния папок
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts -PropertyType DWord -Value 0 -Force