﻿# Do not show when snapping a window, what can be attached next to it
#! Do not modify this string
# Не показывать при прикреплении окна, что можно прикрепить рядом с ним
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist -PropertyType DWord -Value 0 -Force