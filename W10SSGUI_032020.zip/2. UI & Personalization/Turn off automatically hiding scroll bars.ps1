﻿# Turn off automatically hiding scroll bars
#! Do not modify this string
# Отключить автоматическое скрытие полос прокрутки в Windows
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\Accessibility" -Name DynamicScrollbars -PropertyType DWord -Value 0 -Force