﻿# Dismiss Microsoft Defender offer in the Windows Security about signing in Microsoft account
#! Do not modify this string
# Отклонить предложение Microsoft Defender в "Безопасность Windows" о входе в аккаунт Microsoft
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows Security Health\State" -Name AccountProtection_MicrosoftAccount_Disconnected -PropertyType DWord -Value 1 -Force